// Default Config
// Included and shared by content.js, options page, and popup page
const shortcutAutoComplete_default = 'Ctrl+KeyJ';
const shortcutBibtexSearch_default = 'Ctrl+Shift+KeyJ';
const debugEnabled_default = false;
const enableExtension_default = true;
const operatingSystem_default = 'mac';
const keyboardDelay_default = 50;
